document.getElementById("b1").addEventListener("click", startLevel1);

function startLevel1() {
    alert ("Hello World!");
}